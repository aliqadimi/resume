<header id="site_header" class="header">
    <div class="header-content clearfix">

        <!-- Text Logo -->
        <div class="text-logo">
            <a href="/">
                <div class="logo-symbol">A</div>
                <div class="logo-text">Ali <span>Qadimi</span></div>
            </a>
        </div>
        <!-- /Text Logo -->

        <!-- Navigation -->
        <div class="site-nav mobile-menu-hide">
            <ul class="leven-classic-menu site-main-menu">
                <li class="menu-item current-menu-item">
                    <a href="/">About Me</a>
                </li>

                <li class="menu-item">
                    <a href="<?php echo e(route('resume')); ?>">Resume</a>
                </li>


                <li class="menu-item">
                    <a href="<?php echo e(route('blogs')); ?>">Blogs</a>
                </li>

                <li class="menu-item">
                    <a href="<?php echo e(route('contacts')); ?>">Contact</a>
                </li>
            </ul>
        </div>

        <!-- Mobile Menu Toggle -->
        <a class="menu-toggle mobile-visible">
            <i class="fa fa-bars"></i>
        </a>
        <!-- Mobile Menu Toggle -->
    </div>
</header>
<?php /**PATH C:\xampp\htdocs\resume\resources\views/Site/layouts/header.blade.php ENDPATH**/ ?>