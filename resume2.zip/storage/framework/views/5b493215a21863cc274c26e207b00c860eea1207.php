<script src="<?php echo e(asset('Site/js/jquery-2.1.3.min.js')); ?>"></script>
<script src="<?php echo e(asset('Site/js/imagesloaded.pkgd.min.js')); ?>"></script>
<script src='https://www.google.com/recaptcha/api.js'></script>
<script src="<?php echo e(asset('Site/js/bootstrap.min.js')); ?>"></script>
<script src='<?php echo e(asset('Site/js/jquery.shuffle.min.js')); ?>'></script>
<script src='<?php echo e(asset('Site/js/masonry.pkgd.min.js')); ?>'></script>
<script src='<?php echo e(asset('Site/js/owl.carousel.min.js')); ?>'></script>
<script src="<?php echo e(asset('Site/js/jquery.magnific-popup.min.js')); ?>"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCrDf32aQTCVENBhFJbMBKOUTiUAABtC2o"></script>
<script src="<?php echo e(asset('Site/js/jquery.googlemap.js')); ?>"></script>
<script src="<?php echo e(asset('Site/js/validator.js')); ?>"></script>
<script src="<?php echo e(asset('Site/js/main.js')); ?>"></script>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/vaafb692b2aea4879b33c060e79fe94621666317369993"
        integrity="sha512-0ahDYl866UMhKuYcW078ScMalXqtFJggm7TmlUtp0UlD4eQk0Ixfnm5ykXKvGJNFjLMoortdseTfsRT8oCfgGA=="
        data-cf-beacon='{"rayId":"76646774da92549d","version":"2022.11.0","r":1,"token":"94b99c0576dc45bf9d669fb5e9256829","si":100}'
        crossorigin="anonymous"></script>
<?php /**PATH C:\xampp\htdocs\resume\resources\views/Site/layouts/script.blade.php ENDPATH**/ ?>