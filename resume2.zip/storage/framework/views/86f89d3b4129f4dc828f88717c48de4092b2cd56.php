<link rel="shortcut icon" href="favicon.ico">


<link rel="stylesheet" href="<?php echo e(asset('Site/css/normalize.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('Site/css/bootstrap.min.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('Site/css/owl.carousel.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('Site/css/magnific-popup.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('Site/css/main.css')); ?>" type="text/css">

<script src="<?php echo e(asset("Site/js/modernizr.custom.js")); ?>"></script>
<?php /**PATH C:\xampp\htdocs\resume\resources\views/Site/layouts/css.blade.php ENDPATH**/ ?>