<link rel="shortcut icon" href="favicon.ico">


<link rel="stylesheet" href="{{asset('Site/css/normalize.css')}}" type="text/css">
<link rel="stylesheet" href="{{asset('Site/css/bootstrap.min.css')}}" type="text/css">
<link rel="stylesheet" href="{{asset('Site/css/owl.carousel.css')}}" type="text/css">
<link rel="stylesheet" href="{{asset('Site/css/magnific-popup.css')}}" type="text/css">
<link rel="stylesheet" href="{{asset('Site/css/main.css')}}" type="text/css">

<script src="{{asset("Site/js/modernizr.custom.js")}}"></script>
